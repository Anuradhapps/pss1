<?php

namespace Database\Factories\Roles;

use App\Models\Roles\RoleUser;
use Illuminate\Database\Eloquent\Factories\Factory;

class RoleUserFactory extends Factory
{
    protected $model = RoleUser::class;

    public function definition(): array
    {
        return [
            //
        ];
    }
}
