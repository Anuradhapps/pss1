<?php

namespace Database\Factories\Roles;

use App\Models\Roles\Role;
use Illuminate\Database\Eloquent\Factories\Factory;

class RoleFactory extends Factory
{
    protected $model = Role::class;

    public function definition(): array
    {
        return [
            //
        ];
    }
}
